
$(function(){
    $(".twentytwenty-container").twentytwenty();
});
